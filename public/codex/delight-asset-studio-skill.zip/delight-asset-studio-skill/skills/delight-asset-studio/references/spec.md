# Studio Asset Spec

Use this spec with `scripts/render-studio-asset.mjs`. The skill must create
real Studio content data, not a separate visual language.

## Top-Level Shape

```json
{
  "kind": "infographic",
  "slug": "actionbook-editor-steps",
  "content": {
    "schemaVersion": 4,
    "format": "product",
    "bg": "warmgray",
    "accent": "lime",
    "showTitle": false,
    "blocks": []
  }
}
```

`kind` must be one of:

- `infographic`
- `chat-ui`
- `product-visual`

Save specs under `codex/outputs/marketing-assets/<slug>.json`.

## Studio-Reachable Only

Specs are inputs to marketer-facing Studio templates, not arbitrary render data.
Every spec must be producible through visible Studio UI controls. The renderer
rejects unsupported fields before opening the canvas.

Never include:

- `customBackgrounds`, `savedAssets`, `drafts`, or any localStorage-shaped state.
- `data:` URLs, inline SVG/HTML, arbitrary image URLs, or post-render edits.
- Product Visual `conceptScene`, `screenshot`, `reference`, or hidden developer
  tool state for normal marketing assets.
- Arbitrary `bgImage`. Use only built-in Studio background ids where the
  template exposes a background picker.

If a requested image cannot be represented by the shapes below, do not invent a
new shape. Pick the closest supported Studio template/block or report that the
request is unsupported by the current Studio.

For blog/article placement, Product Visual and Infographic specs must use the
Studio `warmgray` background, matching the site's F7F5F0 page color.

## Infographic

Create `content` as `InfographicContent` from `lib/types/infographic.ts`.
Use only Studio block types:

- `stat`: one big proof point or number.
- `kpi-group`: 2-4 short metrics.
- `card-grid`: 1-4 concept cards. One card becomes the Studio "Single card" look.
- `bar-group`: ranked, split, or column bars.
- `stacked-bar`: composition across segments.
- `compare`: before/after cards or table.
- `step`: ordered process.
- `stack`: layered architecture, governance, decision flow.
- `node-list`: hub map with supporting nodes.
- `line-chart`: trend over time.
- `orbit`: loop, cycle, or connected system.

Default to:

```json
{
  "schemaVersion": 4,
  "format": "product",
  "bg": "warmgray",
  "accent": "lime",
  "showTitle": false,
  "blocks": [
    {
      "id": "asset-step",
      "type": "step",
      "items": [
        { "title": "Detect signal", "desc": "Intent and context are checked." },
        { "title": "Apply policy", "desc": "Rules and limits shape the action." },
        { "title": "Suggest action", "desc": "The agent recommends the next step." }
      ]
    }
  ]
}
```

## Chat UI

Create `content` as a chat draft using the store's `ChatDraft` fields. Use only
built-in Studio backgrounds from `lib/backgrounds.ts`; do not use
`customBackgrounds` or `data:` URLs.

```json
{
  "schemaVersion": 4,
  "appName": "delight.ai",
  "backgroundId": "bg-200",
  "layout": "center",
  "exportSize": "desktop",
  "userName": "Taylor",
  "userAvatarUrl": "/preview/Avatar/Woman-07.png",
  "activeScenarioId": "codex-generated",
  "messages": [
    {
      "id": "m1",
      "role": "user",
      "sender": "Taylor",
      "block": { "type": "text", "text": "Can you check my refund status?" }
    },
    {
      "id": "m2",
      "role": "bot",
      "sender": "delight.ai",
      "block": { "type": "text", "text": "I checked the policy and found the next step." }
    }
  ]
}
```

Allowed message blocks come from `lib/store.ts`: `text`, `actions`,
`products`, `checklist`, `status`, `voice`, and `itinerary`.

Use a visible Studio avatar for every Chat UI asset. Set `userAvatarUrl` to one
of the built-in public paths from `data/avatars.json`, for example
`/preview/Avatar/Woman-07.png` or `/preview/Avatar/Man-03.png`. Do not leave
`userAvatarUrl` empty. For user messages, the global `userAvatarUrl` is enough;
per-message `avatar` is optional fallback data.

## Product Visual

Create Product Visual assets with the marketer-facing compact Feature Moment
recipes. Do not hand-author raw `conceptScene` for normal assets. Use
`productMoment.recipe` plus exposed copy slots; the renderer converts this to
the same Studio Feature Moment shape used by Product Visual. During rendering,
the script follows Studio's Product Visual generation path: it restores the
recipe, captures the Concept UI primary panel as the generated screenshot, then
exports `ProductVisualCanvas`. Specs must still omit `conceptScene` and
`screenshot`; those are renderer-internal Studio artifacts, not authored inputs.

Card shape:

```json
{
  "schemaVersion": 4,
  "format": "blog",
  "layout": "center",
  "bg": "warmgray",
  "sourceMode": "concept",
  "title": "Every stalled job gets chased",
  "subtitle": "Agent Steward contacts every party and keeps the case moving.",
  "productMoment": {
    "recipe": "card",
    "slots": {
      "title": "Stalled job chase",
      "reviewer": "Dispatch lead",
      "response": "I contacted parts, OEM, tech, and client at once.",
      "source1": "Depot ETA confirmed",
      "source1Match": "98% match",
      "source2": "OEM diagnostic attached",
      "source2Match": "95% match",
      "secondaryAction": "Review",
      "primaryAction": "Send update"
    }
  }
}
```

Details panel shape:

```json
{
  "schemaVersion": 4,
  "format": "blog",
  "layout": "center",
  "bg": "warmgray",
  "sourceMode": "concept",
  "title": "Every stalled job gets chased",
  "subtitle": "Approval, evidence, and activity history stay visible.",
  "productMoment": {
    "recipe": "details-panel",
    "slots": {
      "title": "Steward details",
      "showInformation": "false",
      "activity1Tag": "Ready",
      "activity1Text": "Job #4816 return visit is ready",
      "activity2Tag": "Evidence logged",
      "activity2Text": "Depot ETA and OEM diagnostic are attached",
      "activity3Tag": "Client updated",
      "activity3Text": "Return window sent after dependencies cleared",
      "activity4Tag": "Review ready",
      "activity4Text": "Supervisor approval has the full case thread"
    }
  }
}
```

Allowed Product Visual recipes:

- `card`: AI answers, generated replies, source/evidence proof, search results,
  concise feature moments.
- `details-panel`: approvals, governance, audit/activity history, human review,
  and object detail views.

Allowed Product Visual formats for generated moments: `blog`,
`release-insert`, and `release-thumbnail`. Use `blog` for blog/article images.
Do not use full dashboard/workspace/builder scenes for marketing assets.

## Routing Heuristics

- Conversation, support assistant, commerce flow -> `chat-ui`.
- Metrics, reports, frameworks, comparisons, process, architecture -> `infographic`.
- Product launch, feature announcement, UI mock, release thumbnail, blog header -> `product-visual`.
- If the brief asks for "images for an article/blog" and mentions structured
  sections, prefer multiple `infographic` specs using different blocks.

## Copy Rules

- Visible copy should be English unless the user explicitly requests Korean.
- Keep text short enough for the selected Studio block.
- Do not use unsupported numeric claims unless supplied by the user.
- Never include API keys, secrets, private screenshots, or customer data.
