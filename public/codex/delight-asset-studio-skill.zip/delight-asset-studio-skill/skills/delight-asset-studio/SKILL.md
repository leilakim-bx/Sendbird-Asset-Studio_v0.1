---
name: delight-asset-studio
description: Create Delight.ai marketing asset PNGs from natural-language briefs using the actual Studio templates, blocks, content models, export canvases, and PMM editorial guardrails. Use when asked to make, revise, export, QA, or generate Chat UI, Infographic, Product Visual, launch thumbnail, blog graphic, campaign visual, release image, or marketing-team asset drafts without adding an LLM API to the web app.
---

# Delight Asset Studio

Use this skill to turn a marketer brief into assets that stay inside the
existing Delight.ai Asset Studio system. The skill must create Studio content
data and render it through the real Next.js Studio components.

## Core Rule

Do not create a separate visual system. Generated assets must be based on:

- Chat UI: `ChatDraft` / `ChatMessage` from `lib/store.ts`, rendered by `FeatureMockup`.
- Infographic: `InfographicContent` from `lib/types/infographic.ts`, rendered by `InfographicCanvas`.
- Product Visual: `ProductVisualContent` from `lib/types/product-visual.ts`, rendered by `ProductVisualCanvas`.

## Studio Reachability Rule

Generated assets must be reachable from marketer-facing Studio controls. It is
not enough that React can render the data. If a marketer could not create the
same image by choosing visible Studio templates, formats, blocks, background
options, recipes, and copy fields, Codex must not create it.

Fail closed for generated specs and prompts:

- Do not use `customBackgrounds`, `data:` URLs, hidden developer tools,
  localStorage-only state, post-render image edits, arbitrary SVG/HTML, or
  direct canvas drawing.
- Do not paste or hand-author raw Product Visual `SceneSpec` for normal
  marketing assets. Product Visual generation must use the marketer-facing
  compact Feature Moment recipes: `card` or `details-panel`, plus exposed copy
  slots only.
- Do not use arbitrary `bgImage` values. If an image background is supported by
  a template, use only Studio's built-in background ids/URLs.
- For blog/article Product Visual and Infographic assets, use the Studio
  `warmgray` background that matches the site's F7F5F0 page color.
- If the brief asks for an image outside Studio capability, choose the closest
  supported Studio template/block or state that the requested visual is not
  currently supported.

## Workflow

1. Read the user's brief and choose `chat-ui`, `infographic`, or `product-visual`.
2. If the brief asks for too many elements in one image, act as a PMM editor:
   split the message into a small asset set instead of overcrowding one template.
3. Read `references/spec.md` before authoring or revising a spec.
4. Create one or more JSON specs under `codex/outputs/marketing-assets/<slug>.json`.
5. Start or reuse the local Studio server, usually `http://localhost:3000`.
6. Render each spec with the actual Studio canvas. The render script validates
   Studio reachability before rendering and must reject unsupported specs:

   ```bash
   node codex/skills/delight-asset-studio/scripts/render-studio-asset.mjs \
     --input codex/outputs/marketing-assets/<slug>.json \
     --output codex/outputs/marketing-assets/<slug>.png \
     --origin http://localhost:3000 \
     --qa
   ```

   To check Studio reachability without launching the browser, run the same
   script with `--validate-only`.

   Product Visual specs render through the same Feature Moment path marketers
   use in Studio: the renderer restores the recipe into Product Visual, captures
   the Concept UI primary panel as the generated screenshot, then exports
   `ProductVisualCanvas`. Do not add `screenshot` or `conceptScene` to specs.

7. Inspect every PNG before handing it off. Check for cropped text, overlap,
   wrong block choice, weak hierarchy, or mismatch with Studio templates.
8. If the user asks for changes, edit the JSON content and rerender.

## Editorial Guardrails

Do not treat every requested detail as something that belongs in one image.
Preserve template clarity before satisfying density.

- Give each image one job: hero/product signal, data explanation, workflow,
  comparison, or conversation example.
- Use one headline, one short supporting message, and a small number of proof
  points per image.
- Keep release thumbnails especially sparse; move details into infographic,
  chat, or additional insert images.
- Split crowded requests into 2-4 images when the user asks to show product UI,
  API fields, dashboards, metrics, customer conversation, and integrations at
  once.
- Explain the split briefly: identify which requested ideas are preserved and
  where each will appear.
- If the user insists on one dense image, state the readability risk and create
  a `Dense` version only after the risk is clear. Default to the recommended
  split.
- Do not invent metrics, customer names, logos, or claims not present in the
  brief. Use directional labels instead.
- If manual QA finds clipping, overlap, tiny text, or weak hierarchy, reduce
  copy or split the asset before final delivery.

## Template Selection

- `chat-ui`: AI agent conversations, support flows, commerce assistant demos,
  message examples, checklist/status/action-button flows.
- `infographic`: reports, metrics, comparisons, frameworks, trends, process
  steps, architectures, lists, article section images.
- `product-visual`: launches, feature announcements, release thumbnails, blog
  headers, product UI concepts, generated Concept UI scenes.

For article/blog requests that need multiple images, create a small set of
Studio-native variations, for example `single-card`, `step`, `compare`, and
`stack` infographic blocks.

## Rules

- Do not edit `app/`, `components/`, `lib/store.ts`, or runtime files unless the
  user explicitly asks to integrate new Studio functionality.
- Do not import `brand.ts` or `app.ts` in generated specs. The Studio renderers
  already read the correct tokens.
- Do not bypass Studio UI capabilities with raw renderer data, custom
  backgrounds, hidden Product Visual developer tools, localStorage state, or
  manual PNG/SVG post-processing.
- Prefer existing block shapes over new abstractions.
- Keep copy short. Use labels, statuses, steps, and concrete outcomes.
- Write visible copy in English unless the user explicitly requests Korean.
- Never put API keys, secrets, customer data, or private screenshots in specs.

## QA

Always render with `--qa`. Script QA checks size and nonblank output only; manual
visual QA is required before the final response.
