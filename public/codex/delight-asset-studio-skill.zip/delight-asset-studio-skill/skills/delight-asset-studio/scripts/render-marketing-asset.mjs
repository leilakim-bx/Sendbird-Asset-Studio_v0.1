#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { pathToFileURL } from "node:url";

const CANVAS = { width: 866, height: 660 };
const DEFAULT_OUT_DIR = path.resolve(process.cwd(), "codex/outputs/marketing-assets");

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!arg.startsWith("--")) continue;
    const key = arg.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      args[key] = true;
    } else {
      args[key] = next;
      index += 1;
    }
  }
  return args;
}

function findRepoRoot(startDir) {
  let current = path.resolve(startDir);
  while (current !== path.dirname(current)) {
    if (fs.existsSync(path.join(current, "lib/tokens/brand.ts"))) return current;
    current = path.dirname(current);
  }
  throw new Error("Could not find repo root containing lib/tokens/brand.ts.");
}

function loadBrand(repoRoot) {
  const brandPath = path.join(repoRoot, "lib/tokens/brand.ts");
  const source = fs.readFileSync(brandPath, "utf8");
  const start = source.indexOf("export const brand = ");
  const end = source.indexOf("\n} as const;");
  if (start === -1 || end === -1) {
    throw new Error("Could not parse lib/tokens/brand.ts.");
  }
  const objectSource = `${source.slice(start).replace("export const brand = ", "").slice(0, end - start - "export const brand = ".length)}\n}`;
  return vm.runInNewContext(`(${objectSource})`, {}, { timeout: 1000 });
}

function clampText(value, maxLength) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 1)).trimEnd()}...`;
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function slugify(value) {
  const slug = String(value || "marketing-asset")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 72);
  return slug || "marketing-asset";
}

function wrapText(text, maxChars, maxLines) {
  const words = String(text || "").split(/\s+/).filter(Boolean);
  const lines = [];
  let current = "";
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
    if (lines.length === maxLines) break;
  }
  if (current && lines.length < maxLines) lines.push(current);
  if (lines.length > maxLines) return lines.slice(0, maxLines);
  if (words.join(" ").length > lines.join(" ").length && lines.length) {
    lines[lines.length - 1] = clampText(lines[lines.length - 1], Math.max(8, maxChars - 1));
  }
  return lines.length ? lines : [""];
}

function textBlock({ text, x, y, maxChars, maxLines = 2, size, lineHeight = 1.2, fill, family, weight = 400, anchor = "start", opacity = 1 }) {
  const lines = wrapText(text, maxChars, maxLines);
  const tspans = lines
    .map((line, index) => {
      const dy = index === 0 ? 0 : size * lineHeight;
      return `<tspan x="${x}" dy="${index === 0 ? 0 : dy}">${escapeXml(line)}</tspan>`;
    })
    .join("");
  return `<text x="${x}" y="${y}" text-anchor="${anchor}" font-family='${escapeXml(family)}' font-size="${size}" font-weight="${weight}" fill="${fill}" opacity="${opacity}">${tspans}</text>`;
}

function rect({ x, y, width, height, fill, radius = 0, stroke, strokeWidth = 1, opacity = 1, filter }) {
  const strokeAttrs = stroke ? ` stroke="${stroke}" stroke-width="${strokeWidth}"` : "";
  const filterAttr = filter ? ` filter="${filter}"` : "";
  return `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="${radius}" fill="${fill}" opacity="${opacity}"${strokeAttrs}${filterAttr}/>`;
}

function line({ x1, y1, x2, y2, stroke, width = 1, opacity = 1 }) {
  return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${width}" opacity="${opacity}" stroke-linecap="round"/>`;
}

function normalizeSpec(raw) {
  const template = ["product-visual", "infographic", "chat-ui"].includes(raw.template)
    ? raw.template
    : "product-visual";
  const accent = ["lime", "blue", "green", "red"].includes(raw.accent) ? raw.accent : "lime";
  const title = clampText(raw.title || "AI agent workflows for modern marketing teams", 92);
  const subtitle = clampText(
    raw.subtitle || "Create a clear product story with governed automation, reusable templates, and export-ready visuals.",
    160,
  );
  const metrics = Array.isArray(raw.metrics) ? raw.metrics.slice(0, 4) : [];
  while (metrics.length < 3) {
    const defaults = [
      { value: "5 min", label: "from brief to asset", caption: "template-led workflow" },
      { value: "3", label: "asset families", caption: "chat, visual, infographic" },
      { value: "1x", label: "consistent brand system", caption: "token-backed output" },
    ];
    metrics.push(defaults[metrics.length]);
  }
  const steps = Array.isArray(raw.steps) ? raw.steps.slice(0, 5).map((step) => clampText(step, 58)) : [];
  while (steps.length < 4) {
    const defaults = [
      "Summarize the campaign brief",
      "Map the message to a template",
      "Generate structured visual content",
      "Export a review-ready PNG",
    ];
    steps.push(defaults[steps.length]);
  }
  const messages = Array.isArray(raw.messages) ? raw.messages.slice(0, 5) : [];
  while (messages.length < 3) {
    const defaults = [
      { role: "user", text: "Can you turn this launch note into a usable campaign asset?" },
      { role: "assistant", text: "I mapped the story to a product visual with three proof points." },
      { role: "assistant", text: "The draft is ready with export-safe copy and brand tokens." },
    ];
    messages.push(defaults[messages.length]);
  }
  return {
    template,
    accent,
    title,
    subtitle,
    eyebrow: clampText(raw.eyebrow || "Delight.ai asset draft", 48),
    audience: clampText(raw.audience || "Marketing team", 56),
    cta: clampText(raw.cta || "Export PNG", 36),
    metrics: metrics.map((metric) => ({
      value: clampText(metric.value || "24/7", 18),
      label: clampText(metric.label || "agent coverage", 38),
      caption: clampText(metric.caption || "ready for review", 44),
    })),
    steps,
    messages: messages.map((message, index) => ({
      role: message.role === "user" ? "user" : "assistant",
      text: clampText(message.text || (index === 0 ? "Can you help?" : "Yes, the draft is ready."), 120),
    })),
  };
}

function specFromBrief(brief) {
  const lower = String(brief || "").toLowerCase();
  const template = lower.includes("chat") || lower.includes("conversation") || lower.includes("assistant")
    ? "chat-ui"
    : lower.includes("infographic") || lower.includes("report") || lower.includes("metric") || lower.includes("trend")
      ? "infographic"
      : "product-visual";
  const sentences = String(brief || "").split(/[.!?]/).map((item) => item.trim()).filter(Boolean);
  const firstSentence = sentences[0] || "Delight.ai marketing asset";
  const stripped = firstSentence
    .replace(/^launch thumbnail for\s+/i, "")
    .replace(/^blog graphic for\s+/i, "")
    .replace(/^marketing asset for\s+/i, "")
    .replace(/^infographic report about\s+/i, "")
    .replace(/^infographic about\s+/i, "")
    .replace(/^chat assistant demo for\s+/i, "")
    .replace(/^chat demo for\s+/i, "")
    .replace(/^create\s+/i, "")
    .replace(/^(a|an|the)\s+/i, "");
  const title = stripped.split(/\s+/).slice(0, 7).join(" ");
  const subtitle = sentences.slice(1).join(". ") || "A template-based Delight.ai marketing asset generated from a natural-language brief.";
  return normalizeSpec({
    template,
    title: clampText(title, 84),
    subtitle: clampText(subtitle, 150),
    eyebrow: "Codex generated draft",
    accent: "lime",
  });
}

function svgShell({ brand, body }) {
  const sans = brand.font.sans;
  const serif = brand.font.serif;
  const bg = brand.color.productVisual.fixedBg.releaseInsert;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${CANVAS.width}" height="${CANVAS.height}" viewBox="0 0 ${CANVAS.width} ${CANVAS.height}" role="img">
  <defs>
    <filter id="shadow-soft" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="18" stdDeviation="20" flood-color="${brand.color.ink}" flood-opacity="0.14"/>
    </filter>
    <filter id="shadow-small" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="9" flood-color="${brand.color.ink}" flood-opacity="0.10"/>
    </filter>
    <style>
      .sans { font-family: ${sans}; }
      .serif { font-family: ${serif}; }
    </style>
  </defs>
  ${rect({ x: 0, y: 0, width: CANVAS.width, height: CANVAS.height, fill: bg })}
  ${body}
</svg>`;
}

function renderProductVisual(spec, brand) {
  const accent = brand.color.infographic.accent[spec.accent];
  const ink = brand.color.ink;
  const muted = brand.color.inkMutedStrong;
  const border = brand.color.border.concept;
  const panel = brand.color.concept.app;
  const surface = brand.color.concept.surface;
  const serif = brand.font.serif;
  const sans = brand.font.sans;
  const r = brand.radius;
  const s = brand.spacing;
  const metricCards = spec.metrics.slice(0, 3).map((metric, index) => {
    const x = 52 + index * 152;
    return [
      rect({ x, y: 486, width: 134, height: 96, fill: brand.color.white, radius: r[14], stroke: border, filter: "url(#shadow-small)" }),
      textBlock({ text: metric.value, x: x + s[14], y: 518, maxChars: 8, maxLines: 1, size: brand.typography.size[24], fill: ink, family: serif, weight: brand.font.weight.semibold }),
      textBlock({ text: metric.label, x: x + s[14], y: 544, maxChars: 17, maxLines: 2, size: brand.typography.size[11], fill: muted, family: sans, weight: brand.font.weight.medium }),
    ].join("");
  }).join("");
  const steps = spec.steps.slice(0, 4).map((step, index) => {
    const y = 322 + index * 44;
    return [
      `<circle cx="548" cy="${y - 4}" r="10" fill="${index === 0 ? accent : surface}" stroke="${border}"/>`,
      textBlock({ text: String(index + 1), x: 548, y, maxChars: 2, maxLines: 1, size: brand.typography.size[10], fill: ink, family: sans, weight: brand.font.weight.bold, anchor: "middle" }),
      textBlock({ text: step, x: 570, y, maxChars: 34, maxLines: 1, size: brand.typography.size[13], fill: ink, family: sans, weight: brand.font.weight.medium }),
    ].join("");
  }).join("");
  const bars = spec.metrics.slice(0, 3).map((metric, index) => {
    const width = [96, 136, 112][index];
    const y = 166 + index * 38;
    return [
      textBlock({ text: metric.label, x: 568, y: y + 8, maxChars: 24, maxLines: 1, size: brand.typography.size[11], fill: muted, family: sans, weight: brand.font.weight.medium }),
      rect({ x: 568, y: y + 17, width: 156, height: 8, fill: surface, radius: r.full }),
      rect({ x: 568, y: y + 17, width, height: 8, fill: index === 1 ? ink : accent, radius: r.full }),
    ].join("");
  }).join("");
  const body = [
    rect({ x: 38, y: 38, width: 790, height: 584, fill: brand.color.white, radius: r[32], opacity: 0.42 }),
    textBlock({ text: spec.eyebrow, x: 52, y: 94, maxChars: 42, maxLines: 1, size: brand.typography.size[12], fill: muted, family: sans, weight: brand.font.weight.semibold }),
    `<circle cx="216" cy="89" r="5" fill="${accent}"/>`,
    textBlock({ text: spec.title, x: 52, y: 164, maxChars: 21, maxLines: 4, size: brand.typography.size[36], lineHeight: 1.06, fill: ink, family: serif, weight: brand.font.weight.semibold }),
    textBlock({ text: spec.subtitle, x: 52, y: 338, maxChars: 47, maxLines: 3, size: brand.typography.size[15], lineHeight: 1.35, fill: muted, family: sans, weight: brand.font.weight.regular }),
    rect({ x: 52, y: 406, width: 148, height: 38, fill: accent, radius: r.full }),
    textBlock({ text: spec.cta, x: 126, y: 430, maxChars: 20, maxLines: 1, size: brand.typography.size[12], fill: ink, family: sans, weight: brand.font.weight.bold, anchor: "middle" }),
    metricCards,
    rect({ x: 492, y: 84, width: 292, height: 456, fill: panel, radius: r[24], stroke: border, filter: "url(#shadow-soft)" }),
    rect({ x: 516, y: 112, width: 244, height: 48, fill: surface, radius: r[16], stroke: border }),
    `<circle cx="542" cy="136" r="10" fill="${accent}"/>`,
    textBlock({ text: "Delight AI console", x: 562, y: 141, maxChars: 24, maxLines: 1, size: brand.typography.size[13], fill: ink, family: sans, weight: brand.font.weight.bold }),
    rect({ x: 724, y: 127, width: 20, height: 18, fill: brand.color.concept.aiSoft, radius: r[8], stroke: border }),
    bars,
    line({ x1: 530, y1: 270, x2: 746, y2: 270, stroke: border }),
    textBlock({ text: "Recommended action path", x: 532, y: 304, maxChars: 28, maxLines: 1, size: brand.typography.size[12], fill: muted, family: sans, weight: brand.font.weight.semibold }),
    steps,
    rect({ x: 526, y: 500, width: 228, height: 28, fill: brand.color.concept.aiSoft, radius: r.full, stroke: border }),
    textBlock({ text: spec.audience, x: 640, y: 519, maxChars: 28, maxLines: 1, size: brand.typography.size[11], fill: ink, family: sans, weight: brand.font.weight.semibold, anchor: "middle" }),
  ].join("");
  return svgShell({ brand, body });
}

function renderInfographic(spec, brand) {
  const accent = brand.color.infographic.accent[spec.accent];
  const ink = brand.color.ink;
  const muted = brand.color.inkMutedStrong;
  const border = brand.color.border.concept;
  const paper = brand.color.infographic.paper;
  const serif = brand.font.serif;
  const sans = brand.font.sans;
  const r = brand.radius;
  const metricCards = spec.metrics.slice(0, 3).map((metric, index) => {
    const x = 54 + index * 252;
    return [
      rect({ x, y: 270, width: 218, height: 122, fill: paper, radius: r[20], stroke: border, filter: "url(#shadow-small)" }),
      textBlock({ text: metric.value, x: x + 22, y: 318, maxChars: 8, maxLines: 1, size: brand.typography.size[31], fill: ink, family: serif, weight: brand.font.weight.semibold }),
      textBlock({ text: metric.label, x: x + 22, y: 350, maxChars: 24, maxLines: 2, size: brand.typography.size[13], fill: ink, family: sans, weight: brand.font.weight.semibold }),
      textBlock({ text: metric.caption, x: x + 22, y: 378, maxChars: 28, maxLines: 1, size: brand.typography.size[11], fill: muted, family: sans }),
    ].join("");
  }).join("");
  const steps = spec.steps.slice(0, 5).map((step, index) => {
    const x = 112 + index * 136;
    return [
      `<circle cx="${x}" cy="488" r="19" fill="${index === 0 ? accent : paper}" stroke="${border}"/>`,
      textBlock({ text: String(index + 1), x, y: 493, maxChars: 2, maxLines: 1, size: brand.typography.size[13], fill: ink, family: sans, weight: brand.font.weight.bold, anchor: "middle" }),
      textBlock({ text: step, x: x - 44, y: 534, maxChars: 15, maxLines: 2, size: brand.typography.size[12], lineHeight: 1.24, fill: ink, family: sans, weight: brand.font.weight.medium }),
      index < 4 ? line({ x1: x + 28, y1: 488, x2: x + 104, y2: 488, stroke: brand.color.infographic.connector, width: 1.4 }) : "",
    ].join("");
  }).join("");
  const body = [
    rect({ x: 36, y: 36, width: 794, height: 588, fill: brand.color.infographic.bg.warmgray, radius: r[32], stroke: border }),
    `<circle cx="748" cy="108" r="58" fill="${accent}" opacity="0.88"/>`,
    `<circle cx="692" cy="142" r="22" fill="${brand.color.white}" opacity="0.72"/>`,
    textBlock({ text: spec.eyebrow, x: 58, y: 94, maxChars: 46, maxLines: 1, size: brand.typography.size[12], fill: muted, family: sans, weight: brand.font.weight.semibold }),
    textBlock({ text: spec.title, x: 58, y: 156, maxChars: 34, maxLines: 2, size: brand.typography.size[36], lineHeight: 1.08, fill: ink, family: serif, weight: brand.font.weight.semibold }),
    textBlock({ text: spec.subtitle, x: 58, y: 230, maxChars: 76, maxLines: 2, size: brand.typography.size[15], lineHeight: 1.35, fill: muted, family: sans }),
    metricCards,
    rect({ x: 54, y: 438, width: 758, height: 148, fill: brand.color.white, radius: r[24], stroke: border }),
    textBlock({ text: spec.cta, x: 76, y: 466, maxChars: 48, maxLines: 1, size: brand.typography.size[13], fill: muted, family: sans, weight: brand.font.weight.semibold }),
    steps,
  ].join("");
  return svgShell({ brand, body });
}

function renderChatUi(spec, brand) {
  const accent = brand.color.infographic.accent[spec.accent];
  const ink = brand.color.ink;
  const muted = brand.color.inkMutedStrong;
  const border = brand.color.chat.glassBorder;
  const sans = brand.font.sans;
  const serif = brand.font.serif;
  const r = brand.radius;
  const messages = spec.messages.slice(0, 5).map((message, index) => {
    const isUser = message.role === "user";
    const width = isUser ? 210 : 246;
    const height = message.text.length > 72 ? 78 : 58;
    const x = isUser ? 548 : 330;
    const y = 208 + index * 78;
    return [
      rect({ x, y, width, height, fill: isUser ? accent : brand.color.chat.bubble, radius: r[18], filter: "url(#shadow-small)" }),
      textBlock({ text: message.text, x: x + 16, y: y + 25, maxChars: isUser ? 26 : 31, maxLines: 2, size: brand.typography.size[13], lineHeight: 1.28, fill: ink, family: sans, weight: brand.font.weight.medium }),
    ].join("");
  }).join("");
  const body = [
    rect({ x: 0, y: 0, width: CANVAS.width, height: CANVAS.height, fill: brand.color.bg.sky }),
    rect({ x: 42, y: 42, width: 782, height: 576, fill: brand.color.white, radius: r[32], opacity: 0.24 }),
    textBlock({ text: spec.eyebrow, x: 64, y: 96, maxChars: 44, maxLines: 1, size: brand.typography.size[12], fill: muted, family: sans, weight: brand.font.weight.semibold }),
    textBlock({ text: spec.title, x: 64, y: 150, maxChars: 13, maxLines: 4, size: brand.typography.size[31], lineHeight: 1.07, fill: ink, family: serif, weight: brand.font.weight.semibold }),
    textBlock({ text: spec.subtitle, x: 64, y: 354, maxChars: 28, maxLines: 3, size: brand.typography.size[15], lineHeight: 1.35, fill: muted, family: sans }),
    rect({ x: 64, y: 486, width: 154, height: 40, fill: accent, radius: r.full }),
    textBlock({ text: spec.cta, x: 141, y: 511, maxChars: 22, maxLines: 1, size: brand.typography.size[12], fill: ink, family: sans, weight: brand.font.weight.bold, anchor: "middle" }),
    rect({ x: 286, y: 68, width: 518, height: 536, fill: brand.color.chat.glassBg, radius: r[32], stroke: border, filter: "url(#shadow-soft)" }),
    rect({ x: 312, y: 94, width: 466, height: 68, fill: brand.color.white, radius: r[20], opacity: 0.72 }),
    `<circle cx="344" cy="128" r="11" fill="${accent}"/>`,
    textBlock({ text: "Delight.ai assistant", x: 366, y: 133, maxChars: 26, maxLines: 1, size: brand.typography.size[14], fill: ink, family: sans, weight: brand.font.weight.bold }),
    textBlock({ text: spec.audience, x: 366, y: 151, maxChars: 36, maxLines: 1, size: brand.typography.size[10], fill: muted, family: sans, weight: brand.font.weight.medium }),
    messages,
    rect({ x: 330, y: 544, width: 424, height: 36, fill: brand.color.white, radius: r.full, opacity: 0.76 }),
    textBlock({ text: "Suggested reply ready", x: 352, y: 567, maxChars: 28, maxLines: 1, size: brand.typography.size[11], fill: muted, family: sans, weight: brand.font.weight.medium }),
  ].join("");
  return svgShell({ brand, body });
}

function renderSvg(spec, brand) {
  if (spec.template === "infographic") return renderInfographic(spec, brand);
  if (spec.template === "chat-ui") return renderChatUi(spec, brand);
  return renderProductVisual(spec, brand);
}

function htmlForSvg(svg, repoRoot) {
  const fontRegular = pathToFileURL(path.join(repoRoot, "public/HelveticaNowText.otf")).href;
  const fontMedium = pathToFileURL(path.join(repoRoot, "public/HelveticaNowTextMedium.otf")).href;
  const fontBold = pathToFileURL(path.join(repoRoot, "public/HelveticaNowTextBold.otf")).href;
  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <style>
      @font-face { font-family: "Helvetica Now Text"; src: url("${fontRegular}") format("opentype"); font-weight: 400; }
      @font-face { font-family: "Helvetica Now Text"; src: url("${fontMedium}") format("opentype"); font-weight: 500 600; }
      @font-face { font-family: "Helvetica Now Text"; src: url("${fontBold}") format("opentype"); font-weight: 700 800; }
      html, body { margin: 0; padding: 0; background: transparent; }
      #asset { width: ${CANVAS.width}px; height: ${CANVAS.height}px; overflow: hidden; }
      svg { display: block; width: ${CANVAS.width}px; height: ${CANVAS.height}px; }
    </style>
  </head>
  <body><div id="asset">${svg}</div></body>
</html>`;
}

async function loadChromium() {
  try {
    const mod = await import("playwright");
    return mod.chromium;
  } catch {
    const mod = await import("@playwright/test");
    return mod.chromium;
  }
}

async function renderPng({ html, outputPath }) {
  const chromium = await loadChromium();
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage({
      viewport: { width: CANVAS.width, height: CANVAS.height },
      deviceScaleFactor: 2,
    });
    await page.setContent(html, { waitUntil: "load" });
    await page.locator("#asset").screenshot({ path: outputPath });
  } finally {
    await browser.close();
  }
}

async function qaPng(outputPath) {
  const chromium = await loadChromium();
  const browser = await chromium.launch({ headless: true });
  try {
    const page = await browser.newPage();
    const dataUrl = `data:image/png;base64,${fs.readFileSync(outputPath).toString("base64")}`;
    const result = await page.evaluate(async ({ dataUrl: url, expectedWidth, expectedHeight }) => {
      const image = new Image();
      image.src = url;
      await image.decode();
      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext("2d");
      context.drawImage(image, 0, 0);
      const sample = context.getImageData(0, 0, canvas.width, canvas.height).data;
      const seen = new Set();
      let colored = 0;
      for (let index = 0; index < sample.length; index += 4 * 197) {
        const key = `${sample[index]},${sample[index + 1]},${sample[index + 2]},${sample[index + 3]}`;
        seen.add(key);
        if (sample[index + 3] > 0) colored += 1;
      }
      return {
        width: image.naturalWidth,
        height: image.naturalHeight,
        expectedWidth,
        expectedHeight,
        uniqueSamples: seen.size,
        coloredSamples: colored,
      };
    }, { dataUrl, expectedWidth: CANVAS.width * 2, expectedHeight: CANVAS.height * 2 });
    if (result.width !== result.expectedWidth || result.height !== result.expectedHeight) {
      throw new Error(`PNG dimensions ${result.width}x${result.height}, expected ${result.expectedWidth}x${result.expectedHeight}.`);
    }
    if (result.uniqueSamples < 10 || result.coloredSamples < 20) {
      throw new Error(`PNG appears blank or too flat: ${JSON.stringify(result)}.`);
    }
    return result;
  } finally {
    await browser.close();
  }
}

function readInputSpec(args) {
  if (args.input) {
    const input = args.input === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(path.resolve(args.input), "utf8");
    return JSON.parse(input);
  }
  if (args.brief) return specFromBrief(args.brief);
  throw new Error("Provide --input <spec.json> or --brief <text>.");
}

async function main() {
  throw new Error(
    "render-marketing-asset.mjs is disabled. Use render-studio-asset.mjs so every output is created through a real Asset Studio template and canvas.",
  );

  const args = parseArgs(process.argv.slice(2));
  const repoRoot = args["repo-root"] ? path.resolve(args["repo-root"]) : findRepoRoot(process.cwd());
  const brand = loadBrand(repoRoot);
  const spec = normalizeSpec(readInputSpec(args));
  const slug = slugify(args.slug || spec.title);
  fs.mkdirSync(DEFAULT_OUT_DIR, { recursive: true });
  const outputPath = path.resolve(args.output || path.join(DEFAULT_OUT_DIR, `${slug}.png`));
  const svgPath = path.resolve(args.svg || path.join(DEFAULT_OUT_DIR, `${slug}.svg`));
  const specOutPath = args["write-spec"] ? path.resolve(args["write-spec"]) : null;
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.mkdirSync(path.dirname(svgPath), { recursive: true });
  if (specOutPath) fs.mkdirSync(path.dirname(specOutPath), { recursive: true });

  const svg = renderSvg(spec, brand);
  fs.writeFileSync(svgPath, svg);
  if (specOutPath) fs.writeFileSync(specOutPath, `${JSON.stringify(spec, null, 2)}\n`);
  await renderPng({ html: htmlForSvg(svg, repoRoot), outputPath });
  const qa = args.qa ? await qaPng(outputPath) : null;
  const result = {
    template: spec.template,
    png: outputPath,
    svg: svgPath,
    spec: specOutPath,
    qa,
  };
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exit(1);
});
