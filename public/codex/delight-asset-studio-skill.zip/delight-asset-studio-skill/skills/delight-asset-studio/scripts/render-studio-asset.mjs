#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const DEFAULT_OUT_DIR = path.resolve(process.cwd(), "codex/outputs/marketing-assets");
const STORE_KEY = "sendbird-editor-v1";
const STORE_VERSION = 5;
const SCHEMA_VERSION = 4;
const DEFAULT_USER_AVATAR_URL = "/preview/Avatar/Woman-07.png";

const CHAT_SIZES = {
  desktop: { width: 866, height: 660 },
  mobile: { width: 343, height: 385 },
};

const INFOGRAPHIC_SIZES = {
  product: { width: 866, height: 660 },
  blog: { width: 664, height: 360 },
};

const PRODUCT_VISUAL_SIZES = {
  "feature-desktop": { width: 866, height: 660 },
  "feature-mobile": { width: 343, height: 480 },
  "release-thumbnail": { width: 667, height: 316 },
  "release-insert": { width: 840, height: 400 },
  blog: { width: 664, height: 400 },
};

const BUILT_IN_BACKGROUND_IDS = new Set([
  "bg-100",
  "bg-101",
  "bg-200",
  "bg-201",
  "bg-202",
  "bg-203",
  "bg-204",
  "bg-300",
  "bg-301",
  "bg-302",
  "bg-500",
  "bg-501",
  "bg-502",
  "bg-503",
  "bg-504",
  "bg-505",
  "bg-600",
  "bg-601",
  "bg-602",
]);

const ALLOWED_CHAT_BLOCK_TYPES = new Set(["text", "actions", "products", "checklist", "status", "voice", "itinerary"]);
const ALLOWED_INFOGRAPHIC_FORMATS = new Set(["product", "blog"]);
const ALLOWED_INFOGRAPHIC_BACKGROUNDS = new Set(["sky", "stone", "warmgray"]);
const ALLOWED_INFOGRAPHIC_ACCENTS = new Set(["lime", "blue", "red", "green"]);
const ALLOWED_INFOGRAPHIC_BLOCK_TYPES = new Set([
  "stat",
  "kpi-group",
  "card-grid",
  "bar-group",
  "stacked-bar",
  "compare",
  "step",
  "stack",
  "node-list",
  "line-chart",
  "orbit",
  "process-loop",
]);
const ALLOWED_PRODUCT_VISUAL_FORMATS = new Set(["blog", "release-insert", "release-thumbnail"]);
const ALLOWED_PRODUCT_VISUAL_BACKGROUNDS = new Set(["white", "sky", "stone", "warmgray", "dark"]);
const ALLOWED_PRODUCT_VISUAL_RECIPES = new Set(["card", "details-panel", "response-card", "approval-modal"]);
const FORBIDDEN_KEYS = new Set([
  "customBackgrounds",
  "savedAssets",
  "drafts",
  "state",
  "localStorage",
  "conceptScene",
  "screenshot",
  "reference",
]);

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!arg.startsWith("--")) continue;
    const key = arg.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      args[key] = true;
    } else {
      args[key] = next;
      index += 1;
    }
  }
  return args;
}

function slugify(value) {
  const slug = String(value || "studio-asset")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 72);
  return slug || "studio-asset";
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(filePath), "utf8"));
}

function failUnsupported(message) {
  throw new Error(`Unsupported Studio asset spec: ${message}`);
}

function assertPlainObject(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    failUnsupported(`${label} must be an object.`);
  }
}

function assertAllowed(value, allowed, label) {
  if (!allowed.has(value)) {
    failUnsupported(`${label} "${value}" is not exposed by Studio.`);
  }
}

function assertNoForbiddenReachabilityData(value, trail = "$") {
  if (typeof value === "string") {
    if (/^\s*data:/i.test(value)) failUnsupported(`${trail} uses a data URL.`);
    if (/<svg|<html|<canvas/i.test(value)) failUnsupported(`${trail} contains inline render markup.`);
    return;
  }
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertNoForbiddenReachabilityData(item, `${trail}[${index}]`));
    return;
  }
  for (const [key, child] of Object.entries(value)) {
    if (FORBIDDEN_KEYS.has(key)) {
      failUnsupported(`${trail}.${key} is not a marketer-facing Studio input.`);
    }
    assertNoForbiddenReachabilityData(child, `${trail}.${key}`);
  }
}

function compactText(value, fallback, maxLength) {
  const text = String(value ?? fallback ?? "").replace(/\s+/g, " ").trim();
  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 3)).trimEnd()}...`;
}

function boolSlot(value, fallback = true) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    if (/^(false|no|0)$/i.test(value.trim())) return false;
    if (/^(true|yes|1)$/i.test(value.trim())) return true;
  }
  return fallback;
}

function tinyPreviewDataUrl() {
  return "data:image/gif;base64,R0lGODlhAQABAAAAACw=";
}

function normalizeKind(rawKind) {
  const kind = String(rawKind || "").toLowerCase();
  if (kind === "chat" || kind === "chat-ui") return "chat-ui";
  if (kind === "infographic") return "infographic";
  if (kind === "product" || kind === "product-visual") return "product-visual";
  throw new Error(`Unsupported studio asset kind: ${rawKind}`);
}

function normalizeProductMomentRecipe(recipe) {
  if (recipe === "response-card") return "card";
  if (recipe === "approval-modal") return "details-panel";
  return recipe;
}

function productMomentSlots(productVisual) {
  const moment = productVisual.productMoment;
  assertPlainObject(moment, "productMoment");
  assertPlainObject(moment.slots || {}, "productMoment.slots");
  const recipe = normalizeProductMomentRecipe(moment.recipe);
  assertAllowed(moment.recipe, ALLOWED_PRODUCT_VISUAL_RECIPES, "productMoment.recipe");
  return { recipe, slots: moment.slots || {} };
}

function buildProductMomentCardScene(productVisual, slots) {
  const title = compactText(slots.title, productVisual.title || "Feature moment", 34);
  const response = compactText(slots.response, "I checked the case and prepared the next action with source evidence.", 150);
  const source1 = compactText(slots.source1, "Source evidence confirmed", 36);
  const source2 = compactText(slots.source2, "Policy and case context checked", 36);
  const source1Match = compactText(slots.source1Match, "98% match", 10);
  const source2Match = compactText(slots.source2Match, "95% match", 10);
  const reviewer = compactText(slots.reviewer, "Team lead", 24);
  const primaryAction = compactText(slots.primaryAction, "Send", 12);
  const secondaryAction = compactText(slots.secondaryAction, "Review", 12);

  return {
    archetype: "modal",
    theme: "light",
    content: {
      productName: compactText(slots.productName, "delight.ai", 28),
      title,
      subtitle: compactText(productVisual.subtitle, "A compact Feature Moment card.", 96),
      background: {
        type: "inbox",
        title: compactText(slots.backgroundTitle, "Case context", 32),
        items: [
          compactText(slots.backgroundItem1, "Customer request", 32),
          compactText(slots.backgroundItem2, "Evidence needed", 32),
          compactText(slots.backgroundItem3, "Agent response", 32),
          compactText(slots.backgroundItem4, "Review ready", 32),
        ],
      },
      modal: {
        slotId: "moment-ai-response",
        kind: "ai-result",
        eyebrow: compactText(slots.eyebrow, "Generated draft", 24),
        title,
        description: compactText(slots.description, "Review the generated response and source evidence before sending.", 96),
        fields: [
          { slotId: "moment-reviewer", label: "Reviewer", value: reviewer },
          { slotId: "moment-response", label: "Response", value: response },
          { slotId: "moment-source-1", label: "Source", value: `${source1}|${source1Match}` },
          { slotId: "moment-source-2", label: "Source", value: `${source2}|${source2Match}` },
        ],
        actions: [
          { label: secondaryAction, tone: "secondary" },
          { label: primaryAction, tone: "primary" },
        ],
      },
    },
    modifiers: {
      highlightedSlotId: "moment-response",
      aiCallout: {
        targetSlotId: "moment-response",
        label: compactText(slots.calloutLabel, "Ready", 14),
        description: compactText(slots.calloutDescription, "The card shows the answer and proof.", 72),
      },
    },
  };
}

function buildProductMomentDetailsScene(productVisual, slots) {
  const title = compactText(slots.title, productVisual.title || "Details panel", 40);
  const showInformation = boolSlot(slots.showInformation, true);
  const fields = [
    { slotId: "moment-show-information", label: "Show information", value: showInformation ? "true" : "false" },
    { slotId: "moment-detail-type", label: "Detail type", value: compactText(slots.detailType, "Case", 42) },
    { slotId: "moment-detail-name", label: "Detail name", value: compactText(slots.detailName, title, 36) },
    { slotId: "moment-detail-status", label: "Detail status", value: compactText(slots.detailStatus, "Ready", 14) },
    { slotId: "moment-detail-time", label: "Detail time", value: compactText(slots.detailTime, "Just now", 16) },
  ];
  for (const index of [1, 2, 3, 4]) {
    fields.push({
      slotId: `moment-activity-${index}-tag`,
      label: `Activity ${index} tag`,
      value: compactText(
        slots[`activity${index}Tag`],
        index === 1 ? "Ready" : index === 2 ? "Evidence logged" : index === 3 ? "Updated" : "Agent review",
        24,
      ),
    });
    fields.push({
      slotId: `moment-activity-${index}-text`,
      label: `Activity ${index} text`,
      value: compactText(
        slots[`activity${index}Text`],
        index === 1
          ? "The case is ready for review."
          : index === 2
            ? "Evidence is attached to the case."
            : index === 3
              ? "The customer update is queued."
              : "Final decision queued for a teammate.",
        64,
      ),
    });
  }

  return {
    archetype: "modal",
    theme: "light",
    content: {
      productName: compactText(slots.productName, "delight.ai", 28),
      title,
      subtitle: compactText(productVisual.subtitle, "A compact details panel.", 96),
      background: {
        type: "inbox",
        title: compactText(slots.backgroundTitle, "Case context", 32),
        items: [
          compactText(slots.backgroundItem1, "Status", 32),
          compactText(slots.backgroundItem2, "Evidence", 32),
          compactText(slots.backgroundItem3, "Review", 32),
          compactText(slots.backgroundItem4, "Activity", 32),
        ],
      },
      modal: {
        slotId: "moment-approval",
        kind: "confirmation",
        eyebrow: compactText(slots.eyebrow, "Details", 24),
        title,
        description: compactText(slots.description, "A cropped operational detail panel with review context.", 96),
        fields,
        actions: [
          { label: compactText(slots.primaryAction, "Approve", 12), tone: "primary" },
          { label: compactText(slots.secondaryAction, "Modify", 12), tone: "secondary" },
        ],
      },
    },
    modifiers: {
      highlightedSlotId: "moment-approval",
      aiCallout: {
        targetSlotId: "moment-approval",
        label: compactText(slots.calloutLabel, "Logged", 14),
        description: compactText(slots.calloutDescription, "Status, evidence, and review context stay in one panel.", 72),
      },
    },
  };
}

function productMomentToScene(productVisual) {
  const { recipe, slots } = productMomentSlots(productVisual);
  return recipe === "details-panel"
    ? buildProductMomentDetailsScene(productVisual, slots)
    : buildProductMomentCardScene(productVisual, slots);
}

function normalizeProductVisualContent(productVisual) {
  assertPlainObject(productVisual, "product-visual content");
  const allowedKeys = new Set([
    "schemaVersion",
    "format",
    "layout",
    "bg",
    "sourceMode",
    "title",
    "subtitle",
    "productMoment",
  ]);
  for (const key of Object.keys(productVisual)) {
    if (!allowedKeys.has(key)) {
      failUnsupported(`Product Visual field "${key}" is not exposed for Codex generation.`);
    }
  }
  if (!productVisual.productMoment) {
    failUnsupported("Product Visual specs must use productMoment.recipe and productMoment.slots.");
  }
  const format = productVisual.format || "blog";
  const layout = productVisual.layout || (format === "release-thumbnail" ? "side-by-side" : "center");
  const bg = productVisual.bg || "warmgray";
  assertAllowed(format, ALLOWED_PRODUCT_VISUAL_FORMATS, "Product Visual format");
  assertAllowed(bg, ALLOWED_PRODUCT_VISUAL_BACKGROUNDS, "Product Visual background");
  if (format === "blog" && bg !== "warmgray") {
    failUnsupported("Product Visual blog format must use the Studio warmgray/F7F5F0 background.");
  }
  if (format === "blog" && layout !== "center") {
    failUnsupported('Product Visual blog format only exposes layout "center".');
  }
  if (format === "release-thumbnail" && layout !== "side-by-side") {
    failUnsupported('Product Visual release-thumbnail format only exposes layout "side-by-side".');
  }
  if (productVisual.sourceMode && productVisual.sourceMode !== "concept") {
    failUnsupported("Generated Product Visual specs must use sourceMode concept.");
  }
  const { productMoment, ...rest } = productVisual;
  return {
    ...rest,
    schemaVersion: SCHEMA_VERSION,
    format,
    layout,
    bg,
    sourceMode: "concept",
    title: compactText(productVisual.title, "Product visual", 72),
    subtitle: productVisual.subtitle ? compactText(productVisual.subtitle, "", 120) : undefined,
    conceptScene: productMomentToScene(productVisual),
  };
}

function validateChatContent(chat) {
  assertPlainObject(chat, "chat-ui content");
  const backgroundId = chat.backgroundId || "bg-200";
  assertAllowed(backgroundId, BUILT_IN_BACKGROUND_IDS, "Chat UI backgroundId");
  if (chat.layout) assertAllowed(chat.layout, new Set(["center", "split"]), "Chat UI layout");
  if (chat.exportSize) assertAllowed(chat.exportSize, new Set(["desktop", "mobile"]), "Chat UI exportSize");
  if (!Array.isArray(chat.messages) || chat.messages.length === 0) {
    failUnsupported("Chat UI requires at least one message.");
  }
  chat.messages.forEach((message, index) => {
    assertPlainObject(message, `chat message ${index + 1}`);
    if (message.role && !["user", "bot", "assistant"].includes(message.role)) {
      failUnsupported(`Chat UI message ${index + 1} uses unsupported role "${message.role}".`);
    }
    assertPlainObject(message.block, `chat message ${index + 1}.block`);
    assertAllowed(message.block.type, ALLOWED_CHAT_BLOCK_TYPES, `Chat UI message ${index + 1} block type`);
  });
}

function validateInfographicContent(infographic) {
  assertPlainObject(infographic, "infographic content");
  const format = infographic.format || "product";
  const bg = infographic.bg || "warmgray";
  assertAllowed(format, ALLOWED_INFOGRAPHIC_FORMATS, "Infographic format");
  assertAllowed(bg, ALLOWED_INFOGRAPHIC_BACKGROUNDS, "Infographic background");
  if (format === "blog" && bg !== "warmgray") {
    failUnsupported("Infographic blog format must use the Studio warmgray/F7F5F0 background.");
  }
  assertAllowed(infographic.accent || "lime", ALLOWED_INFOGRAPHIC_ACCENTS, "Infographic accent");
  if (!Array.isArray(infographic.blocks) || infographic.blocks.length === 0) {
    failUnsupported("Infographic requires at least one Studio block.");
  }
  infographic.blocks.forEach((block, index) => {
    assertPlainObject(block, `infographic block ${index + 1}`);
    assertAllowed(block.type, ALLOWED_INFOGRAPHIC_BLOCK_TYPES, `Infographic block ${index + 1} type`);
  });
}

function normalizeInput(raw) {
  assertPlainObject(raw, "top-level spec");
  assertNoForbiddenReachabilityData(raw);
  const kind = normalizeKind(raw.kind || raw.template || raw.type);
  const slug = slugify(raw.slug || raw.title || raw.name || kind);
  if (kind === "chat-ui") {
    const chat = raw.chat || raw.content;
    if (!chat || typeof chat !== "object") throw new Error("chat-ui input must include `chat` or `content`.");
    validateChatContent(chat);
    return { kind, slug, chat };
  }
  if (kind === "infographic") {
    const infographic = raw.infographic || raw.content;
    if (!infographic || typeof infographic !== "object") throw new Error("infographic input must include `infographic` or `content`.");
    validateInfographicContent(infographic);
    return { kind, slug, infographic };
  }
  const productVisual = raw.productVisual || raw.product_visual || raw.content;
  if (!productVisual || typeof productVisual !== "object") throw new Error("product-visual input must include `productVisual` or `content`.");
  return { kind, slug, productVisual: normalizeProductVisualContent(productVisual) };
}

function persistedStateFor(spec) {
  const base = { customBackgrounds: [], savedAssets: [], drafts: {} };
  if (spec.kind === "chat-ui") {
    const chat = {
      ...spec.chat,
      userAvatarUrl: String(spec.chat.userAvatarUrl || "").trim() || DEFAULT_USER_AVATAR_URL,
    };
    base.drafts.chat = {
      schemaVersion: SCHEMA_VERSION,
      backgroundId: "bg-200",
      layout: "center",
      exportSize: "desktop",
      appName: "delight.ai",
      userName: "Taylor",
      userAvatarUrl: DEFAULT_USER_AVATAR_URL,
      activeScenarioId: "codex-generated",
      ...chat,
    };
  } else if (spec.kind === "infographic") {
    base.drafts.infographic = {
      schemaVersion: SCHEMA_VERSION,
      format: "product",
      bg: "warmgray",
      accent: "lime",
      showTitle: false,
      blocks: [],
      ...spec.infographic,
    };
  } else {
    const productVisual = {
      schemaVersion: SCHEMA_VERSION,
      format: "release-thumbnail",
      layout: "side-by-side",
      bg: "warmgray",
      sourceMode: "concept",
      title: "Product visual",
      ...spec.productVisual,
    };
    base.savedAssets = [
      {
        schemaVersion: SCHEMA_VERSION,
        id: `asset-${Date.now()}`,
        templateId: "product-visual",
        appName: productVisual.title || "Product Visual",
        name: productVisual.title || "Product Visual",
        previewDataUrl: tinyPreviewDataUrl(),
        savedAt: Date.now(),
        productVisual,
      },
    ];
  }
  return { state: base, version: STORE_VERSION };
}

function targetSizeFor(spec) {
  if (spec.kind === "chat-ui") {
    return CHAT_SIZES[spec.chat.exportSize || "desktop"] || CHAT_SIZES.desktop;
  }
  if (spec.kind === "infographic") {
    return INFOGRAPHIC_SIZES[spec.infographic.format || "product"] || INFOGRAPHIC_SIZES.product;
  }
  return PRODUCT_VISUAL_SIZES[spec.productVisual.format || "release-thumbnail"] || PRODUCT_VISUAL_SIZES["release-thumbnail"];
}

function editorPathFor(spec) {
  if (spec.kind === "chat-ui") return "/editor/feature-mockup";
  if (spec.kind === "infographic") return "/editor/infographic";
  return "/open?type=product-visual";
}

async function prepareProductVisual(page, spec) {
  await page.waitForSelector('button[title="Open in editor"]', { timeout: 10000 });
  await page.locator('button[title="Open in editor"]').first().click();
  await page.waitForURL(/\/editor\/product-visual/, { timeout: 10000 });
  await page.waitForSelector('[data-export="1"]', { timeout: 10000 });
  await page.waitForTimeout(500);
}

async function isolateExportTarget(page, spec, size) {
  await page.waitForTimeout(250);
  await page.evaluate(async ({ kind, width, minHeight }) => {
    await document.fonts.ready;

    function rectOf(node) {
      const rect = node.getBoundingClientRect();
      return {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
      };
    }

    const nodes = Array.from(document.querySelectorAll("div"));
    let target = null;
    if (kind === "chat-ui") {
      target = nodes
        .map((node) => ({ node, rect: rectOf(node) }))
        .filter(({ rect }) => rect.x < -9000 && rect.width === width && rect.height >= minHeight)
        .sort((a, b) => a.rect.height - b.rect.height)[0]?.node;
    } else {
      const exportNodes = Array.from(document.querySelectorAll('[data-export="1"]'));
      target = exportNodes
        .map((node) => ({ node, rect: rectOf(node) }))
        .filter(({ rect }) => rect.width === width && rect.height >= minHeight)
        .sort((a, b) => a.rect.height - b.rect.height)[0]?.node ?? exportNodes[0];
    }

    if (!target) throw new Error("Could not find Studio export target.");
    const targetRect = rectOf(target);
    const captureHeight = Math.max(targetRect.height, minHeight);

    document.documentElement.style.margin = "0";
    document.documentElement.style.padding = "0";
    document.documentElement.style.background = "transparent";
    document.body.innerHTML = "";
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.background = "transparent";

    const wrapper = document.createElement("div");
    wrapper.id = "capture";
    wrapper.style.width = `${width}px`;
    wrapper.style.height = `${captureHeight}px`;
    wrapper.style.overflow = "hidden";
    wrapper.style.background = "transparent";
    wrapper.appendChild(target);
    document.body.appendChild(wrapper);
  }, { kind: spec.kind, width: size.width, minHeight: size.height });
}

async function qaPng(page, outputPath, size) {
  const dataUrl = `data:image/png;base64,${fs.readFileSync(outputPath).toString("base64")}`;
  const result = await page.evaluate(async ({ dataUrl: url, expectedWidth, minimumHeight }) => {
    const image = new Image();
    image.src = url;
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    context.drawImage(image, 0, 0);
    const sample = context.getImageData(0, 0, canvas.width, canvas.height).data;
    const seen = new Set();
    let colored = 0;
    for (let index = 0; index < sample.length; index += 4 * 197) {
      const key = `${sample[index]},${sample[index + 1]},${sample[index + 2]},${sample[index + 3]}`;
      seen.add(key);
      if (sample[index + 3] > 0) colored += 1;
    }
    return {
      width: image.naturalWidth,
      height: image.naturalHeight,
      expectedWidth,
      minimumHeight,
      uniqueSamples: seen.size,
      coloredSamples: colored,
    };
  }, { dataUrl, expectedWidth: size.width * 2, minimumHeight: size.height * 2 });

  if (result.width !== result.expectedWidth || result.height < result.minimumHeight) {
    throw new Error(`PNG dimensions ${result.width}x${result.height}, expected width ${result.expectedWidth} and min height ${result.minimumHeight}.`);
  }
  if (result.uniqueSamples < 8 || result.coloredSamples < 20) {
    throw new Error(`PNG appears blank or too flat: ${JSON.stringify(result)}.`);
  }
  return result;
}

async function loadChromium() {
  const candidates = [];
  let current = path.resolve(process.cwd());
  while (current !== path.dirname(current)) {
    candidates.push(path.join(current, "node_modules/playwright/index.mjs"));
    candidates.push(path.join(current, "delight-ai-asset-studio/node_modules/playwright/index.mjs"));
    current = path.dirname(current);
  }
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      const { chromium } = await import(pathToFileURL(candidate).href);
      return chromium;
    }
  }
  try {
    const { chromium } = await import("playwright");
    return chromium;
  } catch (primaryError) {
    throw primaryError;
  }
}

async function render({ spec, origin, outputPath, qa }) {
  const size = targetSizeFor(spec);
  const chromium = await loadChromium();
  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({
      viewport: { width: Math.max(1200, size.width), height: Math.max(1600, size.height) },
      deviceScaleFactor: 2,
    });
    await context.addInitScript(
      ({ key, state }) => window.localStorage.setItem(key, JSON.stringify(state)),
      { key: STORE_KEY, state: persistedStateFor(spec) },
    );
    const page = await context.newPage();
    await page.goto(`${origin}${editorPathFor(spec)}`, { waitUntil: "networkidle" });
    if (spec.kind === "product-visual") await prepareProductVisual(page, spec);
    await isolateExportTarget(page, spec, size);
    await page.locator("#capture").screenshot({ path: outputPath });
    const qaResult = qa ? await qaPng(page, outputPath, size) : null;
    await context.close();
    return { size, qa: qaResult };
  } finally {
    await browser.close();
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.input) throw new Error("Provide --input <studio-spec.json>.");
  const spec = normalizeInput(readJson(args.input));
  if (args["validate-only"]) {
    process.stdout.write(`${JSON.stringify({ kind: spec.kind, slug: spec.slug, valid: true }, null, 2)}\n`);
    return;
  }
  const origin = String(args.origin || "http://localhost:3000").replace(/\/$/, "");
  fs.mkdirSync(DEFAULT_OUT_DIR, { recursive: true });
  const outputPath = path.resolve(args.output || path.join(DEFAULT_OUT_DIR, `${spec.slug}.png`));
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  const result = await render({ spec, origin, outputPath, qa: !!args.qa });
  process.stdout.write(`${JSON.stringify({
    kind: spec.kind,
    png: outputPath,
    size: result.size,
    qa: result.qa,
  }, null, 2)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exit(1);
});
