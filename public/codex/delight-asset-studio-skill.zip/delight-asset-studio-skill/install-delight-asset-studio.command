#!/bin/zsh
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/install-delight-asset-studio.sh"
