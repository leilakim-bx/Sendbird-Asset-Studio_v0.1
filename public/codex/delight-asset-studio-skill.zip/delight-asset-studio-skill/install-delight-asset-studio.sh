#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/skills/delight-asset-studio"
TARGET_DIR="$HOME/.codex/skills/delight-asset-studio"

if [ ! -d "$SOURCE_DIR" ]; then
  echo "Could not find skills/delight-asset-studio in this package."
  exit 1
fi

mkdir -p "$HOME/.codex/skills"
cp -R "$SOURCE_DIR" "$TARGET_DIR"

echo "Installed delight-asset-studio skill to $TARGET_DIR"
echo "Restart Codex, then ask it to use the delight-asset-studio skill."
